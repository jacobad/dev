var canvas = document.getElementById('slate');

var prog = new Program(canvas);

