<?php

/*
 * Database configuration settings used by PDO.
 */

$config['dsn']      = 'mysql:host=localhost;dbname=resto';
$config['password'] = 'troiswa';
$config['user']     = 'root';