<?php

session_start();

var_dump($_SESSION);


include 'header.phtml';
include 'index.phtml';
include 'footer.phtml';

?>